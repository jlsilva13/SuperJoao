package com.example.loginapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    // Declaração dos botões
    Button btnAdicionarBebida, btnConsultarEstoque, btnRelatorioEstoque;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);  // Layout para a tela de início

        // Inicializando os botões
        btnAdicionarBebida = findViewById(R.id.btnAdicionarBebida);
        btnConsultarEstoque = findViewById(R.id.btnConsultarEstoque);
        btnRelatorioEstoque = findViewById(R.id.btnRelatorioEstoque);

        // Ação do botão "Adicionar Bebida"
        btnAdicionarBebida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Exemplo de ação: Exibir um Toast de "Adicionar Bebida"
                Toast.makeText(InicioActivity.this, "Adicionar Bebida", Toast.LENGTH_SHORT).show();
                // Aqui você pode redirecionar para outra Activity para adicionar a bebida
            }
        });

        // Ação do botão "Consultar Estoque"
        btnConsultarEstoque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Exemplo de ação: Exibir um Toast de "Consultar Estoque"
                Toast.makeText(InicioActivity.this, "Consultar Estoque", Toast.LENGTH_SHORT).show();
                // Aqui você pode adicionar lógica para mostrar o estoque de bebidas
            }
        });

        // Ação do botão "Relatório de Estoque"
        btnRelatorioEstoque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Exemplo de ação: Exibir um Toast de "Relatório de Estoque"
                Toast.makeText(InicioActivity.this, "Relatório de Estoque", Toast.LENGTH_SHORT).show();
                // Aqui você pode redirecionar para uma tela que exibe relatórios do estoque
            }
        });
    }
}
